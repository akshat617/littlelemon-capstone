LITTLE LEMON - DJANGO REST FRAMEWORK CAPSTONE

Features
- Django homepage serving HTML and static CSS
- Menu API: list, create, retrieve, update, delete
- Table booking API: list, create, retrieve, update, delete
- MySQL configuration using environment variables
- Djoser registration and token login/logout endpoints
- Unit tests for menu and booking APIs

SETUP
1. Create and activate a virtual environment:
   macOS/Linux:
     python3 -m venv venv
     source venv/bin/activate
   Windows:
     py -m venv venv
     venv\Scripts\activate

2. Install dependencies:
     pip install -r requirements.txt

3. Create a MySQL database:
     CREATE DATABASE littlelemon;

4. Set environment variables to match your MySQL account.
   macOS/Linux:
     export DB_NAME=littlelemon
     export DB_USER=your_mysql_username
     export DB_PASSWORD=your_mysql_password
     export DB_HOST=127.0.0.1
     export DB_PORT=3306
   Windows PowerShell:
     $env:DB_NAME="littlelemon"
     $env:DB_USER="your_mysql_username"
     $env:DB_PASSWORD="your_mysql_password"
     $env:DB_HOST="127.0.0.1"
     $env:DB_PORT="3306"

5. Create migrations and migrate:
     python manage.py makemigrations restaurant
     python manage.py migrate

6. Create an admin account and start the server:
     python manage.py createsuperuser
     python manage.py runserver

Open http://127.0.0.1:8000/
Admin: http://127.0.0.1:8000/admin/

API ROUTES
GET/POST                 /api/menu/
GET/PUT/PATCH/DELETE     /api/menu/<id>/
GET/POST                 /api/bookings/
GET/PUT/PATCH/DELETE     /api/bookings/<id>/
POST                     /auth/users/
POST                     /auth/token/login/
POST                     /auth/token/logout/
POST                     /api-token-auth/

For DRF token authentication in Insomnia, add this header:
Authorization: Token YOUR_TOKEN

TESTS
   python manage.py test restaurant

GITHUB
   git init
   git add .
   git commit -m "Build Little Lemon capstone"
Create an empty GitHub repository, then run:
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
   git push -u origin main

Replace the URL with your own repository URL. Do not commit database passwords or tokens.
This is a starter project. Configure it, run it, and test it before submitting to Coursera.
