from django.urls import path
from .views import (
    BookingDetailView, BookingListCreateView,
    MenuItemDetailView, MenuItemListCreateView,
)
urlpatterns = [
    path("menu/", MenuItemListCreateView.as_view(), name="menu-list"),
    path("menu/<int:pk>/", MenuItemDetailView.as_view(), name="menu-detail"),
    path("bookings/", BookingListCreateView.as_view(), name="booking-list"),
    path("bookings/<int:pk>/", BookingDetailView.as_view(), name="booking-detail"),
]
