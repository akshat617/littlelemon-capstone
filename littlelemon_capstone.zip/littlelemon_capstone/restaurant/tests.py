from datetime import timedelta
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone
from rest_framework.test import APIClient
from .models import Booking, MenuItem

class MenuAPITests(TestCase):
    def setUp(self):
        self.client = APIClient()
        MenuItem.objects.create(title="Greek Salad", price="8.50", inventory=10)

    def test_menu_list_is_public(self):
        response = self.client.get("/api/menu/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data[0]["title"], "Greek Salad")

    def test_menu_create_requires_authentication(self):
        response = self.client.post("/api/menu/", {
            "title": "Pasta", "price": "12.00", "inventory": 5
        }, format="json")
        self.assertEqual(response.status_code, 401)

    def test_authenticated_user_can_create_menu_item(self):
        user = get_user_model().objects.create_user(
            username="tester", password="StrongPass123!"
        )
        self.client.force_authenticate(user=user)
        response = self.client.post("/api/menu/", {
            "title": "Pasta", "price": "12.00", "inventory": 5
        }, format="json")
        self.assertEqual(response.status_code, 201)
        self.assertTrue(MenuItem.objects.filter(title="Pasta").exists())

class BookingAPITests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = get_user_model().objects.create_user(
            username="booker", password="StrongPass123!"
        )
        self.client.force_authenticate(user=self.user)

    def test_authenticated_user_can_create_booking(self):
        response = self.client.post("/api/bookings/", {
            "name": "Test Guest",
            "no_of_guests": 2,
            "booking_date": (timezone.now() + timedelta(days=1)).isoformat(),
        }, format="json")
        self.assertEqual(response.status_code, 201)
        self.assertEqual(Booking.objects.count(), 1)

    def test_booking_list_requires_authentication(self):
        self.client.force_authenticate(user=None)
        response = self.client.get("/api/bookings/")
        self.assertIn(response.status_code, (401, 403))
